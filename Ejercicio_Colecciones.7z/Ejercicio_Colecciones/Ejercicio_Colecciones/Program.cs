﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_Colecciones
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> lista;

            Stack<int> stack = new Stack<int>();

            Queue<int> queue = new Queue<int>();

            Dictionary<string, string> dictionary = new Dictionary<string, string>();

            Random num = new Random();
            lista = new List<int>();

            for (int i=0; i<5; i++)
            {
                lista.Add(num.Next(1, 50));
            }

            lista.Sort(Compare);

            foreach (int numero in lista)
            {
                Console.Write("{0} ", numero);
                stack.Push(numero);
            }

            Console.Write("\n\n");

            foreach (int numero in stack)
            {
                Console.Write("{0} ", numero);
                queue.Enqueue(numero);
            }

            Console.Write("\n\n");

            foreach (int numero in queue)
            {
                Console.Write("{0} ", numero);
            }

            Console.Write("\n\n");

            for (int i=0; i<5; i++)
            {
                dictionary.Add(Convert.ToString(num.Next(40231567, 49658730)), "roberto");
            }

            foreach(KeyValuePair<string, string> elemento in dictionary)
            {
                Console.WriteLine("DNI: {0}\tNombre: {1}", elemento.Key, elemento.Value);
            }

            Console.ReadKey();
        }

        private static int Compare(int x, int y)
        {
            if (x == y)
            {
                return 0;
            }
            else if (x < y)
            {
                return 1;
            }
            else
            {
                return -1;
            }
        }
    }
}
