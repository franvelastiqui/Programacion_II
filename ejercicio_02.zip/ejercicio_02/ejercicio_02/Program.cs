﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_02
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            double cuadrado;
            double cubo;

            Console.WriteLine("Ingrese un numero mayor a 0:");

            numero = Convert.ToInt32(Console.ReadLine());

            while(numero<=0)
            {
                Console.WriteLine("Error. Reingrese un numero mayor a 0:");
                numero = Convert.ToInt32(Console.ReadLine());
            }

            cuadrado = Math.Pow(numero, 2);
            cubo = Math.Pow(numero, 3);

            Console.WriteLine("El numero es {0}, su cuadrado es {1} y su cubo es {2}", numero, cuadrado, cubo);

            Console.ReadKey();
        }
    }
}
