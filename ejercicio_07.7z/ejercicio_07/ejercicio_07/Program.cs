﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_07
{
    class Program
    {
        static void Main(string[] args)
        {
            int dia, mes, anyo;
            bool bisiesto=false;
            int contadorDias = 0;
            int dias;
            bool flag = false;

            Console.WriteLine("Ingrese su dia de nacimiento:");
            dia = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese su mes de nacimiento:");
            mes = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese su año de nacimiento:");
            anyo = Convert.ToInt32(Console.ReadLine());

            for(int i=anyo; i<= DateTime.Now.Year; i++)
            {
                if (i % 4 == 0)
                {
                    bisiesto = true;

                    if (i % 100 == 0 && i % 400 != 0)
                    {
                        bisiesto = false;
                    }
                }
                
                if (anyo!= DateTime.Now.Year)
                {

                    for (int j = mes; j <= 12; j++)
                    {
                        if (j == 1 || j == 3 || j == 5 || j == 7 || j == 8 || j == 10 || j == 12)
                        {
                            contadorDias += 31;
                        }
                        else if (j == 4 || j == 6 || j == 9 || j == 11)
                        {
                            contadorDias += 30;
                        }
                        else if (j == 2 && bisiesto == false)
                        {
                            contadorDias += 28;
                        }
                        else if (j == 2 && bisiesto == true)
                        {
                            contadorDias += 29;
                        }
                    }
                    mes = 1;
                }
                else
                {
                    for(int k=mes; k<DateTime.Now.Month; k++)
                    {
                        if (k == 1 || k == 3 || k == 5 || k == 7 || k == 8 || k == 10 || k == 12)
                        {
                            contadorDias += 31;
                        }
                        else if (k == 4 || k == 6 || k == 9 || k == 11)
                        {
                            contadorDias += 30;
                        }
                        else if (k == 2 && bisiesto == false)
                        {
                            contadorDias += 28;
                        }
                        else if (k == 2 && bisiesto == true)
                        {
                            contadorDias += 29;
                        }
                    }

                    if(mes== DateTime.Now.Month)
                    {
                        dias = DateTime.Now.Day - dia;
                        contadorDias += dias;
                    }
                }

                bisiesto = false;
            }

            

            Console.WriteLine("Los dias son {0}", contadorDias);

            Console.ReadKey();
        }
    }
}
