﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Alumno
    {
        #region Atributos
        private byte nota1;
        private byte nota2;
        private float notaFinal;
        private string apellido;
        private int legajo;
        private string nombre;
        #endregion

        #region Constructores
        public Alumno(string nombre, string apellido, int legajo)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.legajo = legajo;
        }
        #endregion

        #region Metodos

        /// <summary>
        /// Carga la nota del alumno
        /// </summary>
        /// <param name="nota1">Nota del primer parcial</param>
        /// <param name="nota2">Nota del segundo parcial</param>
        public void Estudiar(byte nota1, byte nota2)
        {
            this.nota1 = nota1;
            this.nota2 = nota2;
        }

        /// <summary>
        /// Calcula la nota final del alumno
        /// </summary>
        public void CalcularFinal()
        {
            if(this.nota1>=4 && this.nota2>=4)
            {
                Random r = new Random();
                this.notaFinal = r.Next(1, 11);
            }
            else
            {
                this.notaFinal = -1;
            }
        }

        public string Mostrar()
        {
            string nota;
            string legajo;

            legajo = Convert.ToString(this.legajo);

            if (this.notaFinal!=-1)
            {
                nota = Convert.ToString(this.notaFinal);

                return (legajo + " " + this.nombre + " " + this.apellido + " " + nota);
            }
            else
            {
                return (legajo + " " + this.nombre + " " + this.apellido + " Alumno desaprobado");
            }
        }
        #endregion

    }
}
