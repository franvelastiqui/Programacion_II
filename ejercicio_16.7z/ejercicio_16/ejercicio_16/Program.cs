﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno[] alumnos = new Alumno[3];
            string nombre;
            string apellido;
            int legajo;
            byte nota1;
            byte nota2;
            string mensaje;

            for(int i=0; i<3; i++)
            {
                Console.WriteLine("Ingrese el nombre del alumno:");
                nombre = Console.ReadLine();

                Console.WriteLine("Ingrese el apellido del alumno:");
                apellido = Console.ReadLine();

                Console.WriteLine("Ingrese el legajo del alumno:");
                legajo = Convert.ToInt32(Console.ReadLine());

                alumnos[i] = new Alumno(nombre, apellido, legajo);

                Console.WriteLine("Ingrese la primera nota del alumno:");
                nota1 = Convert.ToByte(Console.ReadLine());

                Console.WriteLine("Ingrese la segunda nota del alumno:");
                nota2 = Convert.ToByte(Console.ReadLine());

                alumnos[i].Estudiar(nota1, nota2);

                alumnos[i].CalcularFinal();

            }

            for(int j=0; j<3; j++)
            {
                mensaje = alumnos[j].Mostrar();

                Console.WriteLine(mensaje);
            }

            Console.ReadKey();
        }
    }
}
