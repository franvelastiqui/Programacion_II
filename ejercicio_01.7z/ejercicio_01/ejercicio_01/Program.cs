﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Primera Clase";

            int numero;
            int max=0;
            int min=0;
            double prom;
            int acum=0;
            bool flag = true;
            
            for(int i=0; i<5; i++)
            {
                Console.WriteLine("Ingrese un numero:");
                numero=Convert.ToInt32(Console.ReadLine());

                if(flag == true)
                {
                    min = numero;
                    max = numero;
                    flag = false;
                }
                else if(numero < min)
                {
                    min = numero;
                }
                else if (numero > max)
                {
                    max = numero;
                }

                acum += numero;
            }

            prom = (double)acum / 5.0;

            Console.Clear();

            Console.WriteLine("El maximo es {0}, el minimo es {1} y el promedio es {2}.", max, min, prom);

            Console.ReadKey();
        }
    
    }
}
