﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio_28
{
    public partial class FormContador : Form
    {
        public FormContador()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            char car = default(char);
            string palabra = default(string);
            int contador = default(int);

            Dictionary<string, int> dictionary = new Dictionary<string, int>();

            string texto = richTextBox.Text;

            texto.Split(' ', ',', '.',';', ':');

            while(car != '\0')
            {

            }

            //foreach(string palabra in texto)
            //{ }
        }
    }
}
