﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio_28
{
    public partial class FormContador : Form
    {
        public FormContador()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            Dictionary<string, int> dictionary = new Dictionary<string, int>();

            string[] texto = richTextBox.Text.Split(' ', ',', '.', ';', ':');

            foreach (string palabra in texto)
            {
                string aux = palabra.ToLower();

                if (dictionary.ContainsKey(aux))
                {
                    dictionary[aux]++;
                }
                else
                {
                    dictionary.Add(aux, 1);
                }
            }

            dictionary.OrderByDescending(KeyValuePair => KeyValuePair.Value);
        }
    }
}
