﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Provincial : Llamada
    {
        #region Atributos

        private Franja franjaHoraria;
        #endregion

        #region Propiedades

        public float CostoLlamada
        {
            get
            {
                return CalcularCosto();
            }
        }
        #endregion

        #region Constructores

        public Provincial(Franja miFranja, Llamada llamada) : this(llamada.NroOrigen, miFranja, llamada.Duracion, llamada.NroDestino)
        {

        }

        public Provincial(string origen, Franja miFranja, float duracion, string destino) : base(duracion, destino, origen)
        {
            this.franjaHoraria = miFranja;
        }
        #endregion

        #region Metodos

        private float CalcularCosto()
        {
            float costo;

            if(this.franjaHoraria==Franja.Franja_1)
            {
                costo = (float)0.99;
            }
            else if(this.franjaHoraria == Franja.Franja_2)
            {
                costo = (float)1.25;
            }
            else
            {
                costo = (float)0.66;
            }

            return (costo*duracion);
        }

        public new string Mostrar()
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendLine("Llamada:\n");
            cadena.AppendFormat("{0}\n", base.Mostrar());
            cadena.AppendFormat("Costo de llamada: {0}\n", this.CalcularCosto());
            cadena.AppendFormat("Franja horaria: {0}\n", this.franjaHoraria);

            return (cadena.ToString());
        }
        #endregion

        #region Anidados

        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3
        }
        #endregion
    }
}
