﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Centralita
    {
        #region Atributos

        private List<Llamada> listaDeLlamadas;
        private string razonSocial;
        #endregion

        #region Propiedades

        public float GananciaPorLocal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Local);
            }
        }

        public float GananciaPorProvincial
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Provincial);
            }
        }

        public float GananciaPorTotal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Todas);
            }
        }

        public List<Llamada> Llamadas
        {
            get
            {
                return this.listaDeLlamadas;
            }
        }
        #endregion

        #region Constructores

        public Centralita()
        {
            listaDeLlamadas = new List<Llamada>();
        }

        public Centralita(string nombreEmpresa) : this()
        {
            this.razonSocial = nombreEmpresa;
        }
        #endregion

        #region Metodos

        private float CalcularGanancia(Llamada.TipoLlamada tipo)
        {
            float retorno;

            switch(tipo)
            {
                case Llamada.TipoLlamada.Local:
                    retorno = 0;
                    break;
                case Llamada.TipoLlamada.Provincial:
                    retorno = 0;
                    break;
                default:
                    retorno = 0;
                    break;
            }

            return retorno;
        }

        public string Mostrar()
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendFormat("Empresa: {0}\n", this.razonSocial);
            cadena.AppendFormat("Ganancia total: {0}\n", this.GananciaPorTotal);
            cadena.AppendFormat("Ganancia local: {0}\n", this.GananciaPorLocal);
            cadena.AppendFormat("Ganancia provincial: {0}\n", this.GananciaPorProvincial);
            foreach(Llamada llamada in listaDeLlamadas)
            {
                cadena.AppendFormat("Detalles de llamada: {0}\n", llamada);
            }

            return (cadena.ToString());
        }

        public void OrdenarLlamadas()
        {
            this.listaDeLlamadas.Sort(Llamada.OrdenarPorDuracion);
        }
        #endregion
    }
}
