﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Local : Llamada
    {
        #region Atributos

        private float costo;
        #endregion

        #region Propiedades

        public float CostoLlamada
        {
            get
            {
                return this.costo;
            }
        }    
        #endregion

        #region Constructores

        public Local(Llamada llamada, float costo) : this(llamada.NroOrigen, llamada.Duracion, llamada.NroDestino, costo)
        {
            
        }

        public Local(string origen, float duracion, string destino, float costo) : base(duracion, destino, origen)
        {
            this.costo = costo;
        }
        #endregion

        #region Metodos

        private float CalcularCosto()
        {
            return (duracion*costo);
        }

        public new string Mostrar()
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendLine("Llamada:\n");
            cadena.AppendFormat("{0}\n", base.Mostrar());
            cadena.AppendFormat("Costo de llamada: {0}\n", this.costo);

            return (cadena.ToString());
        }
        #endregion
    }
}
