﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Llamada
    {
        #region Atributos

        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;
        #endregion

        #region Propiedades

        public float Duracion
        {
            get
            {
                return this.duracion;
            }
        }

        public string NroDestino
        {
            get
            {
                return this.nroDestino;
            }
        }

        public string NroOrigen
        {
            get
            {
                return this.nroOrigen;
            }
        }
        #endregion

        #region Constructor

        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }
        #endregion

        #region Metodos

        public string Mostrar()
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendFormat("Duracion de llamada: {0}\n", this.duracion);
            cadena.AppendFormat("Numero de destino: {0}\n", this.nroDestino);
            cadena.AppendFormat("Numero de origen: {0}\n", this.nroOrigen);

            return (cadena.ToString());
        }

        public static int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            if (llamada1.duracion < llamada2.duracion)
            {
                return 1;
            }
            else if (llamada1.duracion == llamada2.duracion)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
        #endregion

        #region Anidados

        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }
        #endregion
    }
}
