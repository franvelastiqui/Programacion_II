﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_14
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            double numeroDos;
            double areaCuadrado;
            double areaTriangulo;
            double areaCirculo;

            Console.WriteLine("Ingrese el lado del cuadrado: ");
            numero = Convert.ToDouble(Console.ReadLine());

            areaCuadrado = CalculoDeArea.CalcularCuadrado(numero);

            Console.WriteLine("Ingrese la base del triangulo: ");
            numero = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese la altura del triangulo: ");
            numeroDos = Convert.ToDouble(Console.ReadLine());

            areaTriangulo = CalculoDeArea.CalcularTriangulo(numero, numeroDos);

            Console.WriteLine("Ingrese el radio del circulo: ");
            numero = Convert.ToDouble(Console.ReadLine());

            areaCirculo = CalculoDeArea.CalcularCirculo(numero);

            Console.WriteLine("Area de cuadrado: {0}\nArea de triangulo: {1}\nArea de circulo: {2}", areaCuadrado, areaTriangulo, areaCirculo);

            Console.ReadKey();

        }
    }
}
