﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_12
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            bool validacion;
            char respuesta;
            int acumulador = default(Int32);

            do
            {
                Console.WriteLine("Ingrese un numero:");
                numero = Convert.ToInt32(Console.ReadLine());

                acumulador += numero;

                Console.WriteLine("Ingrese S si desea continuar:");
                respuesta = Convert.ToChar(Console.ReadLine());

                validacion = ValidarRespuesta.ValidaS_N(respuesta);
            } while (validacion == true);

            Console.WriteLine("El resultado es {0}", acumulador);

            Console.ReadKey();
        }
    }
}
