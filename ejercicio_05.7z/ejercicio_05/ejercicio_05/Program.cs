﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_05
{
    class Program
    {
        static void Main(string[] args)
        {
            int numeroIngresado;
            int acumuladorAnterior = 0;
            int acumuladorPosterior = 0;

            Console.WriteLine("Ingrese un numero:");
            numeroIngresado = Convert.ToInt32(Console.ReadLine());

            for(int i=2; i<=numeroIngresado; i++)
            {
                for(int j=i-1; j>0; j--)
                {
                    acumuladorAnterior += j;
                }

                for(int k=i+1; acumuladorPosterior<acumuladorAnterior; k++)
                {
                    acumuladorPosterior += k;
                }

                if(acumuladorPosterior==acumuladorAnterior)
                {
                    Console.WriteLine("{0} es un centro numerico", i);
                }

                acumuladorAnterior = 0;
                acumuladorPosterior = 0;
            }

            Console.ReadKey();
        }
    }
}
