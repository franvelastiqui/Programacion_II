﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_Clase_5
{
    class Estante
    {
        private int ubicacionEstante;
        private Producto[] productos;

        private Estante(int capacidad)
        {
            this.productos = new Producto[capacidad];
        }

        public Estante(int capacidad, int ubicacion):this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }

        public Producto[] GetProductos()
        {
            return this.productos;
        }

        public string MostrarEstante(Estante e)
        {
            string retorno2 = string.Empty;

            for(int i=0; i<(e.productos).Length; i++)
            {
                retorno2 += Producto.MostrarProducto(e.productos[i]);
                retorno2 += string.Format(" - Ubicacion: {0}\n", e.ubicacionEstante);
            }

            return retorno2;
        }

        public static bool operator !=(Estante e, Producto p)
        {
            if (e is null || p is null)
            {
                return false;
            }
            else
            {
                for(int i=0; i<(e.productos).Length; i++)
                {
                    if (e.productos[i] != p)
                    {
                        return false;
                    }
                }

                return true;
            }
        }

        public static bool operator ==(Estante e, Producto p)
        {
            if (e is null || p is null)
            {
                return false;
            }
            else
            {
                for (int i = 0; i < (e.productos).Length; i++)
                {
                    if (e.productos[i] == p)
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        public static bool operator +(Estante e, Producto p)
        {
            Estante auxiliar = e;

            if (e is null || p is null)
            {
                return false;
            }
            else
            {
                auxiliar.productos[((auxiliar.productos).Length) + 1] = p;

                if(auxiliar is null)
                {
                    return false;
                }
                else
                {
                    for (int i = 0; i < (e.productos).Length; i++)
                    {
                        if (e.productos[i] == p)
                        {
                            return false;
                        }
                    }

                    e.productos[((e.productos).Length) + 1] = p;

                    return true;
                }
            }
        }

        public static Estante operator -(Estante e, Producto p)
        {
            Estante auxiliar = e;

            for (int i = 0; i < (e.productos).Length; i++)
            {
                if(e.productos[i] == p)
                {
                    e.productos[i] = null;
                    break;
                }
            }

            return e;
        }
    }
}
