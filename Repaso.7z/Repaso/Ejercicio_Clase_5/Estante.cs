﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_Clase_5
{
    class Estante
    {
        private int ubicacionEstante;
        private Producto[] productos;

        private Estante(int capacidad)
        {
            this.productos = new Producto[capacidad];
        }

        public Estante(int capacidad, int ubicacion):this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }

        public Producto[] GetProductos()
        {
            return this.productos;
        }

        public static string MostrarEstante(Estante e)
        {
            string retorno = string.Empty;
            retorno += String.Format("Estante. Ubicacion: {0}\n", e.ubicacionEstante);
            retorno += "\nProductos: \n";

            foreach(Producto p in e.GetProductos())
            {
                if(!(p is null))
                {
                    retorno += Producto.MostrarProducto(p) + "\n";
                }
                
            }

            return retorno;
        }

        public static bool operator !=(Estante e, Producto p)
        {
            if (e is null || p is null)
            {
                return false;
            }
            else
            {
                for(int i=0; i<(e.productos).Length; i++)
                {
                    if (e.productos[i] != p)
                    {
                        return false;
                    }
                }

                return true;
            }
        }

        public static bool operator ==(Estante e, Producto p)
        {
            if (e is null || p is null)
            {
                return false;
            }
            else
            {
                for (int i = 0; i < (e.productos).Length; i++)
                {
                    if (e.productos[i] == p)
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        public static bool operator +(Estante e, Producto p)
        {
            Estante auxiliar = e;

            bool retorno = false;

            if(e!=p)
            {
                Producto[] productos = e.GetProductos();

                for(int i=0;i<e.GetProductos().Length; i++)
                {
                    if(productos[i] is null)
                    {
                        productos[i] = p;
                        retorno = true;
                        break;
                    }
                }
            }
            return retorno;
        }

        public static Estante operator -(Estante e, Producto p)
        {
            Estante auxiliar = e;

            for (int i = 0; i < (e.productos).Length; i++)
            {
                if(e.productos[i] == p)
                {
                    e.productos[i] = null;
                    break;
                }
            }

            return e;
        }
    }
}
