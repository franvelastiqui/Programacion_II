﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_Clase_5
{
    class Producto
    {
        private string codigoDeBarra;
        private string marca;
        private float precio;

        public Producto(string marca, string codigo, float precio)
        {
            this.marca = marca;
            this.codigoDeBarra = codigo;
            this.precio = precio;
        }

        public string GetMarca()
        {
            return this.marca;
        }

        public float GetPrecio()
        {
            return this.precio;
        }

        public static string MostrarProducto(Producto p)
        {
            string retorno = string.Empty;

            retorno += string.Format("Codigo: {0}", p.codigoDeBarra);
            retorno += string.Format(" - Marca: {0}", p.marca);
            retorno += string.Format(" - Precio: {0}", p.precio);

            return retorno;
        }

        public static explicit operator string(Producto p)
        {
            string objeto = Convert.ToString(p);

            return p.codigoDeBarra;
        }

        public static bool operator !=(Producto p, string marca)
        {
            if(p is null)
            {
                return false;
            }
            else
            {
                if(p.marca != marca)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public static bool operator ==(Producto p, string marca)
        {
            if (p is null)
            {
                return false;
            }
            else
            {
                if (p.marca == marca)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public static bool operator !=(Producto p1, Producto p2)
        {
            if (p1 is null || p2 is null)
            {
                return false;
            }
            else
            {
                if (p1.marca != p2.marca || p1.codigoDeBarra != p2.codigoDeBarra)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public static bool operator ==(Producto p1, Producto p2)
        {
            if (p1 is null || p2 is null)
            {
                return false;
            }
            else
            {
                if (p1.marca == p2.marca && p1.codigoDeBarra == p2.codigoDeBarra)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
