﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    class Euro
    {
        #region Atributos

        private double cantidad;
        private static double cotizRespectoDolar;
        #endregion

        #region Constructor estatico

        static Euro()
        {
            Euro.cotizRespectoDolar = default(double);
        }
        #endregion

        #region Constructores de instacia

        public Euro(double cantidad)
        {
            this.cantidad = cantidad;
        }

        public Euro(double cantidad, double cotizacion) : this(cantidad)
        {
            Euro.cotizRespectoDolar = cotizacion;
        }
        #endregion

        #region Getters

        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static double GetCotizacion()
        {
            return Euro.cotizRespectoDolar;
        }
        #endregion

        #region Sobrecargas explicitas e implicitas

        public static explicit operator Dolar(Euro p)
        {
            return (Dolar)p;
        }

        public static explicit operator Pesos(Euro p)
        {
            return (Pesos)p;
        }

        public static implicit operator Euro(double d)
        {
            Euro euro = new Euro(d);

            return euro;
        }
        #endregion

        #region Sobrecargas de operadores de comparacion

        public static bool operator ==(Euro e, Dolar d)
        {
            return (e.cantidad == d.GetCantidad());
        }

        public static bool operator !=(Euro e, Dolar d)
        {
            return !(e == d);
        }

        public static bool operator ==(Euro e, Pesos p)
        {
            return (e.cantidad == p.GetCantidad());
        }

        public static bool operator !=(Euro e, Pesos p)
        {
            return !(e == p);
        }

        public static bool operator ==(Euro e1, Euro e2)
        {
            return (e1.cantidad == e2.cantidad);
        }

        public static bool operator !=(Euro e1, Euro e2)
        {
            return !(e1 == e2);
        }
        #endregion

        #region Sobrecargar de operadores de aritmetica


        #endregion
    }
}
