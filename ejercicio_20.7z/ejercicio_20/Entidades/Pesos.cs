﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    class Pesos
    {
        #region Atributos

        private double cantidad;
        private static double cotizRespectoDolar;
        #endregion

        #region Constructor estatico

        static Pesos()
        {
            Pesos.cotizRespectoDolar = default(double);
        }
        #endregion

        #region Constructores de instancia

        public Pesos(double cantidad)
        {
            this.cantidad = cantidad;
        }

        public Pesos(double cantidad, double cotizacion) : this(cantidad)
        {
            Pesos.cotizRespectoDolar = cotizacion;
        }
        #endregion

        #region Getters

        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static double GetCotizacion()
        {
            return Pesos.cotizRespectoDolar;
        }
        #endregion

        #region Sobrecargas explicitas e implicitas

        public static explicit operator Dolar(Pesos p)
        {
            return (Dolar)p;
        }

        public static explicit operator Euro(Pesos p)
        {
            return (Euro)p;
        }

        public static implicit operator Pesos(double d)
        {
            Pesos pesos = new Pesos(d);

            return pesos;
        }
        #endregion

        #region Sobrecargas de operadores de comparacion

        public static bool operator ==(Pesos p, Dolar d)
        {
            return (p.cantidad == d.GetCantidad());
        }

        public static bool operator !=(Pesos p, Dolar d)
        {
            return !(p == d);
        }

        public static bool operator ==(Pesos p, Euro e)
        {
            return (p.cantidad == e.GetCantidad());
        }

        public static bool operator !=(Pesos p, Euro e)
        {
            return !(p == e);
        }

        public static bool operator ==(Pesos p1, Pesos p2)
        {
            return (p1.cantidad == p2.cantidad);
        }

        public static bool operator !=(Pesos p1, Pesos p2)
        {
            return !(p1 == p2);
        }
        #endregion

        #region Sobrecargar de operadores de aritmetica

        public static Pesos operator +(Pesos p, Dolar d)
        {
            d = d.GetCantidad() * Dolar.GetCotizacion();

            return p + d;
        }

        public static Pesos operator -(Pesos p, Dolar d)
        {
            d = d.GetCantidad() * Dolar.GetCotizacion();

            return p - d;
        }

        public static Pesos operator +(Pesos p, Euro e)
        {
            e = e.GetCantidad() * Euro.GetCotizacion();

            return p + e;
        }

        public static Pesos operator -(Pesos p, Euro e)
        {
            e = e.GetCantidad() * Pesos.GetCotizacion();

            return p - e;
        }
        #endregion
    }
}
