﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Rectangulo : Figura
    {
        protected double basee;
        protected double altura;

        public Rectangulo(double basee, double altura)
        {
            this.basee = basee;
            this.altura = altura;
        }

        public override string Dibujar()
        {
            return "Dibujando rectangulo...";
        }

        public override double CalcularSuperficie()
        {
            return (this.basee * this.altura);
        }

        public override double CalcularPerimetro()
        {
            return ((this.altura * 2) + (this.basee * 2));
        }
    }
}
