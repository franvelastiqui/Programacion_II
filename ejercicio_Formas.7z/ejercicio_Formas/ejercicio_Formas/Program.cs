﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace ejercicio_Formas
{
    class Program
    {
        static void Main(string[] args)
        {
            int contador = 0;

            List<Figura> figuras = new List<Figura>();

            figuras.Add(new Cuadrado(5));
            figuras.Add(new Rectangulo(4, 5));
            figuras.Add(new Circulo(4));

            foreach (Figura figura in figuras)
            {
                contador += 1;
                Console.WriteLine("Figura {0}\nTipo: {1}\n{2}\nArea: {3}\nPerimetro: {4}\n", contador, figura.GetType(), figura.Dibujar(), figura.CalcularSuperficie(), figura.CalcularPerimetro());
            }

            Console.ReadKey();
        }
    }
}
