﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_15
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            double numeroDos;
            char operacion;
            double resultado;
            char respuesta;

            do
            {
                Console.WriteLine("Ingrese el primer numero: ");
                numero = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese el segundo numero:");
                numeroDos = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Ingrese la operacion: ");
                operacion = Convert.ToChar(Console.ReadLine());

                if (operacion == '+' || operacion == '-' || operacion == '*' || operacion == '/')
                {
                    resultado = Calculadora.Calcular(numero, numeroDos, operacion);

                    Console.WriteLine("El resultado es {0}", resultado);
                }
                else
                {
                    Console.WriteLine("Error. Ingresar una operacion no valida");
                }

                Console.WriteLine("Ingrese S si desea continuar:");
                respuesta = Convert.ToChar(Console.ReadLine());

            } while (respuesta == 's' || respuesta == 'S');

            Console.ReadKey();
        }
    }
}
