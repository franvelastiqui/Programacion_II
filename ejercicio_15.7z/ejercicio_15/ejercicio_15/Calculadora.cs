﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_15
{
    class Calculadora
    {
        public static double Calcular(double numeroUno, double numeroDos, char operacion)
        {
            double resultado = default(double);

            if(operacion=='+')
            {
                resultado = (numeroUno + numeroDos);
            }
            else if(operacion=='-')
            {
                resultado = (numeroUno - numeroDos);
            }
            else if(operacion=='*')
            {
                resultado = (numeroUno * numeroDos);
            }
            else
            {
                if(Validar(numeroDos)==true)
                {
                    resultado = (numeroUno / numeroDos);
                }
            }

            return resultado;
        }

        private static bool Validar(double numeroDos)
        {
            if(numeroDos==0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
