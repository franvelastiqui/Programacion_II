﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_04
{
    class Program
    {
        static void Main(string[] args)
        {
            int contador=0;
            int acumulador = 0;

        for(int i=1; contador<4; i++)
            {
                for(int j=i-1; j>0; j--)
                {
                    if (i % j == 0)
                    {
                        acumulador += j;
                    }
                }

                if(acumulador==i)
                {
                    Console.WriteLine("Numero perfecto: {0}", i);
                    contador++;
                }

                acumulador = 0;
            }

            Console.ReadKey();
        }
    }
}
