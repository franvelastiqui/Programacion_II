﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Negocio
    {
        #region Atributos

        private PuestoAtencion caja;
        private Queue<Cliente> clientes;
        private string nombre;
        #endregion

        #region Propiedades

        public Cliente Cliente
        {
            get
            {

            }
            set
            {

            }
        }

        #endregion

        #region Constructores

        public Negocio()
        {
            this.caja = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);
        }

        public Negocio(string nombre)
        {
            this.nombre = nombre;
        }
        #endregion

        #region Sobrecargas

        public static bool operator !=(Negocio n, Cliente c)
        {
            return (n != c);
        }

        public static bool operator ==(Negocio n, Cliente c)
        {
            return (n == c);
        }

        public static bool operator +(Negocio n, Cliente c)
        {
            return (n + c);
        }

        public static bool operator ~(Negocio n)
        {
            return (~n);
        }
        #endregion
    }
}
