﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class PuestoAtencion
    {
        #region Atributos

        private static int numeroActual;
        private Puesto puesto;
        #endregion

        #region Propiedades

        public static int NumeroActual
        {
            get
            {
                return (numeroActual + 1);
            }
        }
        #endregion

        #region Constructores

        static PuestoAtencion()
        {
            numeroActual = 0;
        }

        public PuestoAtencion(Puesto puesto)
        {
            
        }
        #endregion

        #region Metodos

        public bool Atender(Cliente cli)
        {
            System.Threading.Thread.Sleep(5000);
            return true;
        }
        #endregion

        #region Tipos anidados

        public enum Puesto
        {
            Caja1 = 1,
            Caja2
        }
        #endregion
    }
}
