﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_17
{
    class Program
    {
        static void Main(string[] args)
        {
            Boligrafo[] boligrafos = new Boligrafo[2];

            boligrafos[0] = new Boligrafo(100, ConsoleColor.Blue);
            boligrafos[1] = new Boligrafo(50, ConsoleColor.Red);

        }
    }
}
