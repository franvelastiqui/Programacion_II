﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_03
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int contador = 0;
            bool flag = false;

            Console.WriteLine("Ingrese un numero:");
            numero = Convert.ToInt32(Console.ReadLine());

            if(numero>1)
            {
                for (int i = 2; i < numero; i++)
                {
                    for(int j = i-1; j > 0 ; j--)
                    {
                        if(i % j == 0)
                        {
                            contador++;
                        }
                        if(contador>=2)
                        {
                            flag = true;
                        }
                    }

                    if(flag==false)
                    {
                        Console.WriteLine("El numero {0} es primo", i);
                    }

                    flag = false;
                    contador = 0;
                }
            }
            else
            {
                Console.WriteLine("No hay primos");
            }

            Console.ReadKey();
        }
    }
}
