﻿namespace ejercicio_21
{
    partial class FormConversor
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormConversor));
            this.textoCotizacion = new System.Windows.Forms.Label();
            this.textoEuro = new System.Windows.Forms.Label();
            this.textoDolar = new System.Windows.Forms.Label();
            this.textoPeso = new System.Windows.Forms.Label();
            this.textBoxEuro = new System.Windows.Forms.TextBox();
            this.textBoxDolar = new System.Windows.Forms.TextBox();
            this.textBoxPeso = new System.Windows.Forms.TextBox();
            this.buttonEuro = new System.Windows.Forms.Button();
            this.buttonDolar = new System.Windows.Forms.Button();
            this.buttonPeso = new System.Windows.Forms.Button();
            this.buttonCandado = new System.Windows.Forms.Button();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.textBoxCotEuro = new System.Windows.Forms.TextBox();
            this.textBoxCotDolar = new System.Windows.Forms.TextBox();
            this.textBoxCotPeso = new System.Windows.Forms.TextBox();
            this.labelConvEuro = new System.Windows.Forms.Label();
            this.labelConvDolar = new System.Windows.Forms.Label();
            this.labelConvPeso = new System.Windows.Forms.Label();
            this.textBoxEuroEuro = new System.Windows.Forms.TextBox();
            this.textBoxDolarEuro = new System.Windows.Forms.TextBox();
            this.textBoxPesoEuro = new System.Windows.Forms.TextBox();
            this.textBoxEuroDolar = new System.Windows.Forms.TextBox();
            this.textBoxDolarDolar = new System.Windows.Forms.TextBox();
            this.textBoxPesoDolar = new System.Windows.Forms.TextBox();
            this.textBoxEuroPeso = new System.Windows.Forms.TextBox();
            this.textBoxDolarPeso = new System.Windows.Forms.TextBox();
            this.textBoxPesoPeso = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textoCotizacion
            // 
            this.textoCotizacion.AutoSize = true;
            this.textoCotizacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoCotizacion.Location = new System.Drawing.Point(45, 19);
            this.textoCotizacion.Name = "textoCotizacion";
            this.textoCotizacion.Size = new System.Drawing.Size(66, 13);
            this.textoCotizacion.TabIndex = 0;
            this.textoCotizacion.Text = "Cotización";
            // 
            // textoEuro
            // 
            this.textoEuro.AutoSize = true;
            this.textoEuro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoEuro.Location = new System.Drawing.Point(10, 67);
            this.textoEuro.Name = "textoEuro";
            this.textoEuro.Size = new System.Drawing.Size(33, 13);
            this.textoEuro.TabIndex = 1;
            this.textoEuro.Text = "Euro";
            // 
            // textoDolar
            // 
            this.textoDolar.AutoSize = true;
            this.textoDolar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoDolar.Location = new System.Drawing.Point(7, 97);
            this.textoDolar.Name = "textoDolar";
            this.textoDolar.Size = new System.Drawing.Size(37, 13);
            this.textoDolar.TabIndex = 2;
            this.textoDolar.Text = "Dólar";
            // 
            // textoPeso
            // 
            this.textoPeso.AutoSize = true;
            this.textoPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoPeso.Location = new System.Drawing.Point(7, 129);
            this.textoPeso.Name = "textoPeso";
            this.textoPeso.Size = new System.Drawing.Size(35, 13);
            this.textoPeso.TabIndex = 3;
            this.textoPeso.Text = "Peso";
            // 
            // textBoxEuro
            // 
            this.textBoxEuro.Location = new System.Drawing.Point(45, 60);
            this.textBoxEuro.Name = "textBoxEuro";
            this.textBoxEuro.Size = new System.Drawing.Size(100, 20);
            this.textBoxEuro.TabIndex = 4;
            // 
            // textBoxDolar
            // 
            this.textBoxDolar.Location = new System.Drawing.Point(48, 94);
            this.textBoxDolar.Name = "textBoxDolar";
            this.textBoxDolar.Size = new System.Drawing.Size(100, 20);
            this.textBoxDolar.TabIndex = 5;
            // 
            // textBoxPeso
            // 
            this.textBoxPeso.Location = new System.Drawing.Point(45, 129);
            this.textBoxPeso.Name = "textBoxPeso";
            this.textBoxPeso.Size = new System.Drawing.Size(100, 20);
            this.textBoxPeso.TabIndex = 6;
            // 
            // buttonEuro
            // 
            this.buttonEuro.Location = new System.Drawing.Point(154, 59);
            this.buttonEuro.Name = "buttonEuro";
            this.buttonEuro.Size = new System.Drawing.Size(75, 20);
            this.buttonEuro.TabIndex = 7;
            this.buttonEuro.Text = "->";
            this.buttonEuro.UseVisualStyleBackColor = true;
            this.buttonEuro.Click += new System.EventHandler(this.buttonEuro_Click);
            // 
            // buttonDolar
            // 
            this.buttonDolar.Location = new System.Drawing.Point(154, 94);
            this.buttonDolar.Name = "buttonDolar";
            this.buttonDolar.Size = new System.Drawing.Size(75, 20);
            this.buttonDolar.TabIndex = 8;
            this.buttonDolar.Text = "->";
            this.buttonDolar.UseVisualStyleBackColor = true;
            this.buttonDolar.Click += new System.EventHandler(this.buttonDolar_Click);
            // 
            // buttonPeso
            // 
            this.buttonPeso.Location = new System.Drawing.Point(154, 129);
            this.buttonPeso.Name = "buttonPeso";
            this.buttonPeso.Size = new System.Drawing.Size(75, 20);
            this.buttonPeso.TabIndex = 9;
            this.buttonPeso.Text = "->";
            this.buttonPeso.UseVisualStyleBackColor = true;
            this.buttonPeso.Click += new System.EventHandler(this.buttonPeso_Click);
            // 
            // buttonCandado
            // 
            this.buttonCandado.ImageIndex = 0;
            this.buttonCandado.ImageList = this.imageList;
            this.buttonCandado.Location = new System.Drawing.Point(154, 9);
            this.buttonCandado.Name = "buttonCandado";
            this.buttonCandado.Size = new System.Drawing.Size(75, 23);
            this.buttonCandado.TabIndex = 10;
            this.buttonCandado.UseVisualStyleBackColor = true;
            this.buttonCandado.Click += new System.EventHandler(this.buttonCandado_Click);
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "lock-open-solid.png");
            this.imageList.Images.SetKeyName(1, "lock-solid.png");
            // 
            // textBoxCotEuro
            // 
            this.textBoxCotEuro.Location = new System.Drawing.Point(261, 11);
            this.textBoxCotEuro.Name = "textBoxCotEuro";
            this.textBoxCotEuro.Size = new System.Drawing.Size(100, 20);
            this.textBoxCotEuro.TabIndex = 11;
            this.textBoxCotEuro.Leave += new System.EventHandler(this.textBoxCotEuro_Leave);
            // 
            // textBoxCotDolar
            // 
            this.textBoxCotDolar.Location = new System.Drawing.Point(368, 11);
            this.textBoxCotDolar.Name = "textBoxCotDolar";
            this.textBoxCotDolar.Size = new System.Drawing.Size(100, 20);
            this.textBoxCotDolar.TabIndex = 12;
            this.textBoxCotDolar.Leave += new System.EventHandler(this.textBoxCotDolar_Leave);
            // 
            // textBoxCotPeso
            // 
            this.textBoxCotPeso.Location = new System.Drawing.Point(475, 11);
            this.textBoxCotPeso.Name = "textBoxCotPeso";
            this.textBoxCotPeso.Size = new System.Drawing.Size(100, 20);
            this.textBoxCotPeso.TabIndex = 13;
            this.textBoxCotPeso.Leave += new System.EventHandler(this.textBoxCotPeso_Leave);
            // 
            // labelConvEuro
            // 
            this.labelConvEuro.AutoSize = true;
            this.labelConvEuro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConvEuro.Location = new System.Drawing.Point(258, 43);
            this.labelConvEuro.Name = "labelConvEuro";
            this.labelConvEuro.Size = new System.Drawing.Size(33, 13);
            this.labelConvEuro.TabIndex = 14;
            this.labelConvEuro.Text = "Euro";
            // 
            // labelConvDolar
            // 
            this.labelConvDolar.AutoSize = true;
            this.labelConvDolar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConvDolar.Location = new System.Drawing.Point(365, 43);
            this.labelConvDolar.Name = "labelConvDolar";
            this.labelConvDolar.Size = new System.Drawing.Size(37, 13);
            this.labelConvDolar.TabIndex = 15;
            this.labelConvDolar.Text = "Dólar";
            // 
            // labelConvPeso
            // 
            this.labelConvPeso.AutoSize = true;
            this.labelConvPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConvPeso.Location = new System.Drawing.Point(472, 43);
            this.labelConvPeso.Name = "labelConvPeso";
            this.labelConvPeso.Size = new System.Drawing.Size(35, 13);
            this.labelConvPeso.TabIndex = 16;
            this.labelConvPeso.Text = "Peso";
            // 
            // textBoxEuroEuro
            // 
            this.textBoxEuroEuro.Location = new System.Drawing.Point(261, 60);
            this.textBoxEuroEuro.Name = "textBoxEuroEuro";
            this.textBoxEuroEuro.Size = new System.Drawing.Size(100, 20);
            this.textBoxEuroEuro.TabIndex = 17;
            // 
            // textBoxDolarEuro
            // 
            this.textBoxDolarEuro.Location = new System.Drawing.Point(261, 94);
            this.textBoxDolarEuro.Name = "textBoxDolarEuro";
            this.textBoxDolarEuro.Size = new System.Drawing.Size(100, 20);
            this.textBoxDolarEuro.TabIndex = 18;
            // 
            // textBoxPesoEuro
            // 
            this.textBoxPesoEuro.Location = new System.Drawing.Point(261, 129);
            this.textBoxPesoEuro.Name = "textBoxPesoEuro";
            this.textBoxPesoEuro.Size = new System.Drawing.Size(100, 20);
            this.textBoxPesoEuro.TabIndex = 19;
            // 
            // textBoxEuroDolar
            // 
            this.textBoxEuroDolar.Location = new System.Drawing.Point(368, 59);
            this.textBoxEuroDolar.Name = "textBoxEuroDolar";
            this.textBoxEuroDolar.Size = new System.Drawing.Size(100, 20);
            this.textBoxEuroDolar.TabIndex = 20;
            // 
            // textBoxDolarDolar
            // 
            this.textBoxDolarDolar.Location = new System.Drawing.Point(368, 94);
            this.textBoxDolarDolar.Name = "textBoxDolarDolar";
            this.textBoxDolarDolar.Size = new System.Drawing.Size(100, 20);
            this.textBoxDolarDolar.TabIndex = 21;
            // 
            // textBoxPesoDolar
            // 
            this.textBoxPesoDolar.Location = new System.Drawing.Point(368, 129);
            this.textBoxPesoDolar.Name = "textBoxPesoDolar";
            this.textBoxPesoDolar.Size = new System.Drawing.Size(100, 20);
            this.textBoxPesoDolar.TabIndex = 22;
            // 
            // textBoxEuroPeso
            // 
            this.textBoxEuroPeso.Location = new System.Drawing.Point(475, 59);
            this.textBoxEuroPeso.Name = "textBoxEuroPeso";
            this.textBoxEuroPeso.Size = new System.Drawing.Size(100, 20);
            this.textBoxEuroPeso.TabIndex = 23;
            // 
            // textBoxDolarPeso
            // 
            this.textBoxDolarPeso.Location = new System.Drawing.Point(475, 94);
            this.textBoxDolarPeso.Name = "textBoxDolarPeso";
            this.textBoxDolarPeso.Size = new System.Drawing.Size(100, 20);
            this.textBoxDolarPeso.TabIndex = 24;
            // 
            // textBoxPesoPeso
            // 
            this.textBoxPesoPeso.Location = new System.Drawing.Point(475, 129);
            this.textBoxPesoPeso.Name = "textBoxPesoPeso";
            this.textBoxPesoPeso.Size = new System.Drawing.Size(100, 20);
            this.textBoxPesoPeso.TabIndex = 25;
            // 
            // FormConversor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 167);
            this.Controls.Add(this.textBoxPesoPeso);
            this.Controls.Add(this.textBoxDolarPeso);
            this.Controls.Add(this.textBoxEuroPeso);
            this.Controls.Add(this.textBoxPesoDolar);
            this.Controls.Add(this.textBoxDolarDolar);
            this.Controls.Add(this.textBoxEuroDolar);
            this.Controls.Add(this.textBoxPesoEuro);
            this.Controls.Add(this.textBoxDolarEuro);
            this.Controls.Add(this.textBoxEuroEuro);
            this.Controls.Add(this.labelConvPeso);
            this.Controls.Add(this.labelConvDolar);
            this.Controls.Add(this.labelConvEuro);
            this.Controls.Add(this.textBoxCotPeso);
            this.Controls.Add(this.textBoxCotDolar);
            this.Controls.Add(this.textBoxCotEuro);
            this.Controls.Add(this.buttonCandado);
            this.Controls.Add(this.buttonPeso);
            this.Controls.Add(this.buttonDolar);
            this.Controls.Add(this.buttonEuro);
            this.Controls.Add(this.textBoxPeso);
            this.Controls.Add(this.textBoxDolar);
            this.Controls.Add(this.textBoxEuro);
            this.Controls.Add(this.textoPeso);
            this.Controls.Add(this.textoDolar);
            this.Controls.Add(this.textoEuro);
            this.Controls.Add(this.textoCotizacion);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormConversor";
            this.Text = "Conversor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label textoCotizacion;
        private System.Windows.Forms.Label textoEuro;
        private System.Windows.Forms.Label textoDolar;
        private System.Windows.Forms.Label textoPeso;
        private System.Windows.Forms.TextBox textBoxEuro;
        private System.Windows.Forms.TextBox textBoxDolar;
        private System.Windows.Forms.TextBox textBoxPeso;
        private System.Windows.Forms.Button buttonEuro;
        private System.Windows.Forms.Button buttonDolar;
        private System.Windows.Forms.Button buttonPeso;
        private System.Windows.Forms.Button buttonCandado;
        private System.Windows.Forms.TextBox textBoxCotEuro;
        private System.Windows.Forms.TextBox textBoxCotDolar;
        private System.Windows.Forms.TextBox textBoxCotPeso;
        private System.Windows.Forms.Label labelConvEuro;
        private System.Windows.Forms.Label labelConvDolar;
        private System.Windows.Forms.Label labelConvPeso;
        private System.Windows.Forms.TextBox textBoxEuroEuro;
        private System.Windows.Forms.TextBox textBoxDolarEuro;
        private System.Windows.Forms.TextBox textBoxPesoEuro;
        private System.Windows.Forms.TextBox textBoxEuroDolar;
        private System.Windows.Forms.TextBox textBoxDolarDolar;
        private System.Windows.Forms.TextBox textBoxPesoDolar;
        private System.Windows.Forms.TextBox textBoxEuroPeso;
        private System.Windows.Forms.TextBox textBoxDolarPeso;
        private System.Windows.Forms.TextBox textBoxPesoPeso;
        private System.Windows.Forms.ImageList imageList;
    }
}

