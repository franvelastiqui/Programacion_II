﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Billetes;

namespace ejercicio_21
{
    public partial class FormConversor : Form
    {
        public FormConversor()
        {
            InitializeComponent();
        }

        private void buttonCandado_Click(object sender, EventArgs e)
        {
            this.buttonCandado.ImageIndex = this.buttonCandado.ImageIndex == 1 ? 0 : 1;

            this.textBoxCotEuro.Enabled = !this.textBoxCotEuro.Enabled;
            this.textBoxCotDolar.Enabled = !this.textBoxCotDolar.Enabled;
            this.textBoxCotPeso.Enabled = !this.textBoxCotPeso.Enabled;
        }

        private void buttonEuro_Click(object sender, EventArgs e)
        {
            Euro eu = new Euro(Convert.ToDouble(textBoxEuro.Text));

            textBoxEuroEuro.Text = Convert.ToString(eu.GetCantidad());
            textBoxEuroDolar.Text = (Convert.ToString(((Dolar)eu).GetCantidad()));
            textBoxEuroPeso.Text = (Convert.ToString(((Pesos)eu).GetCantidad()));
        }

        private void buttonDolar_Click(object sender, EventArgs e)
        {

        }

        private void buttonPeso_Click(object sender, EventArgs e)
        {

        }

        private void textBoxCotEuro_Leave(object sender, EventArgs e)
        {
            Euro.SetCotizacion(Convert.ToDouble(this.Text));
        }

        private void textBoxCotDolar_Leave(object sender, EventArgs e)
        {
            Dolar.SetCotizacion(Convert.ToDouble(this.Text));
        }

        private void textBoxCotPeso_Leave(object sender, EventArgs e)
        {
            Pesos.SetCotizacion(Convert.ToDouble(this.Text));
        }
    }
}
