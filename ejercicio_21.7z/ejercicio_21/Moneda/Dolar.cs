﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Dolar
    {
        #region Atributos

        private double cantidad;
        private static double cotizRespectoDolar;
        #endregion

        #region Constructor estatico

        static Dolar()
        {
            Dolar.cotizRespectoDolar = default(double);
        }
        #endregion

        #region Constructores de instancia

        public Dolar(double cantidad)
        {
            this.cantidad = cantidad;
        }
        
        public Dolar(double cantidad, double cotizacion):this(cantidad)
        {
            Dolar.cotizRespectoDolar = cotizacion;
        }
        #endregion

        #region Getters

        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static double GetCotizacion()
        {
            return Dolar.cotizRespectoDolar;
        }
        #endregion

        #region Setter

        public static void SetCotizacion(double numero)
        {
            Dolar.cotizRespectoDolar = numero;
        }
        #endregion

        #region Sobrecargas explicitas e implicitas

        public static explicit operator Euro(Dolar d)
        {
            return (Euro)d;
        }

        public static explicit operator Pesos(Dolar d)
        {
            return (Pesos)d;
        }

        public static implicit operator Dolar(double d)
        {
            Dolar dolar = new Dolar(d);

            return dolar;
        }
        #endregion

        #region Sobrecargas de operadores de comparacion

        public static bool operator ==(Dolar d, Euro e)
        {
            return (d.cantidad == e.GetCantidad());
        }

        public static bool operator !=(Dolar d, Euro e)
        {
            return !(d == e);
        }

        public static bool operator ==(Dolar d, Pesos p)
        {
            return (d.cantidad == p.GetCantidad());
        }

        public static bool operator !=(Dolar d, Pesos p)
        {
            return !(d == p);
        }

        public static bool operator ==(Dolar d1, Dolar d2)
        {
            return (d1.cantidad == d2.cantidad);
        }

        public static bool operator !=(Dolar d1, Dolar d2)
        {
            return !(d1 == d2);
        }
        #endregion

        #region Sobrecargar de operadores de aritmetica

        public static Dolar operator +(Dolar d, Euro e)
        {
            Dolar aux = new Dolar(d.cantidad + ((Dolar)e).GetCantidad());

            return aux;
        }

        public static Dolar operator -(Dolar d, Euro e)
        {
            Dolar aux = new Dolar(d.cantidad - ((Dolar)e).GetCantidad());

            return aux;
        }

        public static Dolar operator +(Dolar d, Pesos p)
        {
            Dolar aux = new Dolar(d.cantidad + ((Dolar)p).GetCantidad());

            return aux;
        }

        public static Dolar operator -(Dolar d, Pesos p)
        {
            Dolar aux = new Dolar(d.cantidad - ((Dolar)p).GetCantidad());

            return aux;
        }
        #endregion
    }
}
