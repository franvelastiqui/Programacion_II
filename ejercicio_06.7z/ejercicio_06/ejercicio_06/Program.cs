﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_06
{
    class Program
    {
        static void Main(string[] args)
        {
            int primerAnio;
            int segundoAnio;
            bool flag = false;

            Console.WriteLine("Ingrese el primer año:");
            primerAnio=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese el segundo año:");
            segundoAnio = Convert.ToInt32(Console.ReadLine());

            for(int i=primerAnio; i<=segundoAnio; i++)
            {
                if(i%4==0)
                {
                    flag = true;

                    if(i%100==0 && i%400!=0)
                    {
                        flag = false;
                    }
                }

                if (flag == true)
                {
                    Console.WriteLine("El año {0} es bisiesto", i);
                }

                    flag = false;
            }

            Console.ReadKey();
        }
    }
}
