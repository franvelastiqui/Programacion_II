﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            bool validacion;
            int min = default(Int32);
            int max = default(Int32);
            int acumulador = default(Int32);
            int promedio;
            bool flag = default(bool);

            for(int i=0; i<10; i++)
            {
                Console.WriteLine("Ingrese un valor entre -100 y 100:");
                numero = Convert.ToInt32(Console.ReadLine());

                validacion = Validacion.Validar(numero, -100, 100);
                
                while(validacion==false)
                {
                    Console.WriteLine("Error. Ingrese un valor entre -100 y 100:");
                    numero = Convert.ToInt32(Console.ReadLine());
                    validacion = Validacion.Validar(numero, -100, 100);
                }

                if (flag == false)
                {
                    min = numero;
                    max = numero;
                    flag = true;
                }
                else if (min < numero)
                {
                    min = numero;
                }
                else if (max > numero)
                {
                    max = numero;
                }

                acumulador += numero;
            }

            promedio = acumulador / 10;

            Console.WriteLine("El minimo es {0}, el maximo es {1} y el promedio es {2}", min, max, promedio);

            Console.ReadKey();
        }
    }
}
